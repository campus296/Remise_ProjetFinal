﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetJeuGo.Models
{
    public class JournalPartie
    {
        public string NomJoueurNoir { get; set; } = "";
        public string NomJoueurBlanc { get; set; } = "";
        public string NomGagnant { get; set; } = "";
        public TimeSpan TempsPartie { get; set; }
    }
}
