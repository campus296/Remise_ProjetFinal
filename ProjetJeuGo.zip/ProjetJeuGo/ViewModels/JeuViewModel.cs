﻿using ProjetJeuGo.Commands;
using ProjetJeuGo.Models;
using ProjetJeuGo.Services;
using ProjetJeuGo.Views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Threading;

namespace ProjetJeuGo.ViewModels
{
    public class JeuViewModel : BaseViewModel
    {
        private readonly DispatcherTimer _timer;

        private string _gagnant = "";

        private int _passesConsecutives = 0;

        private string _etatInterditKo = "";

        private Pierre _joueurActuel = Pierre.Black;

        private TimeSpan _tempsNoir;
        private TimeSpan _tempsBlanc;

        private int _capturesNoir;
        private int _capturesBlanc;

        private bool _estEnPause;

        private double _territoireNoir;
        private double _territoireBlanc;

        public Plateau Plateau { get; set; }

        public ICommand CellClickCommand { get; }
        public ICommand PasserTourCommand { get; }
        public ICommand PauseCommand { get; }
        public ICommand AbandonnerCommand { get; }

        public string NomJoueurNoir { get; set; }
        public string NomJoueurBlanc { get; set; }

        public double Komi { get; set; }

        public string Gagnant
        {
            get => _gagnant;
            set
            {
                _gagnant = value;
                OnPropertyChanged(nameof(Gagnant));
            }
        }

        public Pierre JoueurActuel
        {
            get => _joueurActuel;
            set
            {
                _joueurActuel = value;
                OnPropertyChanged(nameof(JoueurActuel));
                OnPropertyChanged(nameof(NomJoueurActuel));
            }
        }

        public string NomJoueurActuel
        {
            get
            {
                return JoueurActuel == Pierre.Black
                    ? NomJoueurNoir
                    : NomJoueurBlanc;
            }
        }

        public TimeSpan TempsNoir
        {
            get => _tempsNoir;
            set
            {
                _tempsNoir = value;
                OnPropertyChanged(nameof(TempsNoir));
                OnPropertyChanged(nameof(TempsPartie));
            }
        }

        public TimeSpan TempsBlanc
        {
            get => _tempsBlanc;
            set
            {
                _tempsBlanc = value;
                OnPropertyChanged(nameof(TempsBlanc));
                OnPropertyChanged(nameof(TempsPartie));
            }
        }

        public TimeSpan TempsPartie
        {
            get => TempsNoir + TempsBlanc;
        }

        public int CapturesNoir
        {
            get => _capturesNoir;
            set
            {
                _capturesNoir = value;
                OnPropertyChanged(nameof(CapturesNoir));
                OnPropertyChanged(nameof(ScoreNoir));
            }
        }

        public int CapturesBlanc
        {
            get => _capturesBlanc;
            set
            {
                _capturesBlanc = value;
                OnPropertyChanged(nameof(CapturesBlanc));
                OnPropertyChanged(nameof(ScoreBlanc));
            }
        }

        public double ScoreNoir
        {
            get => CapturesNoir + TerritoireNoir;
        }

        public double ScoreBlanc
        {
            get => CapturesBlanc + Komi + TerritoireBlanc;
        }

        public bool EstEnPause
        {
            get => _estEnPause;
            set
            {
                _estEnPause = value;
                OnPropertyChanged(nameof(EstEnPause));
            }
        }

        public double TerritoireNoir
        {
            get => _territoireNoir;
            set
            {
                _territoireNoir = value;
                OnPropertyChanged(nameof(TerritoireNoir));
                OnPropertyChanged(nameof(ScoreNoir));
            }
        }

        public double TerritoireBlanc
        {
            get => _territoireBlanc;
            set
            {
                _territoireBlanc = value;
                OnPropertyChanged(nameof(TerritoireBlanc));
                OnPropertyChanged(nameof(ScoreBlanc));
            }
        }


        public JeuViewModel() : this("Joueur noir", "Joueur blanc", 9, 6.5)
        {

        }
        public JeuViewModel(string nomJoueurNoir,
                            string nomJoueurBlanc,
                            int taillePlateau,
                            double komi)
        {
            NomJoueurNoir = nomJoueurNoir;
            NomJoueurBlanc = nomJoueurBlanc;
            Komi = komi;

            Plateau = new Plateau(taillePlateau);

            CellClickCommand = new RelayCommand(OnCellClicked);
            PasserTourCommand = new RelayCommand(PasserTour);
            PauseCommand = new RelayCommand(Pause);
            AbandonnerCommand = new RelayCommand(Abandonner);

            _timer = new DispatcherTimer();
            _timer.Interval = TimeSpan.FromSeconds(1);
            _timer.Tick += Timer_Tick;
            _timer.Start();
        }

        private void Timer_Tick(object? sender, EventArgs e)
        {
            if (EstEnPause)
                return;

            if (JoueurActuel == Pierre.Black)
                TempsNoir += TimeSpan.FromSeconds(1);
            else
                TempsBlanc += TimeSpan.FromSeconds(1);
        }


        //Cette méthode est appelée lorsqu’un joueur clique sur une intersection du plateau.
        private void OnCellClicked(object? parameter)
        {
            if (EstEnPause)
                return;

            Intersection? intersection = parameter as Intersection;

            if (intersection == null)
                return;

            if (intersection.Value != Pierre.Empty)
            {
                MessageBox.Show(
                    "Cette intersection est déjà occupée.",
                    "Coup invalide",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);

                return;
            }

            string etatAvantCoup = GetEtatPlateau();

            Pierre joueur = JoueurActuel;
            Pierre adversaire = GetCouleurAdverse(joueur);

            intersection.Value = joueur;

            List<Intersection> pierresCapturees = new List<Intersection>();

            int captures = CapturerGroupesAdverses(intersection,adversaire,pierresCapturees);

            string etatApresCoup = GetEtatPlateau();

            // Règle du ko normale
            if (etatApresCoup == _etatInterditKo)
            {
                intersection.Value = Pierre.Empty;

                foreach (Intersection pierreCapturee in pierresCapturees)
                    pierreCapturee.Value = adversaire;

                MessageBox.Show(
                    "Coup interdit : règle du ko.",
                    "Coup invalide",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);

                return;
            }

            if (captures > 0)
            {
                _etatInterditKo = etatAvantCoup;
            }

            // Suicide interdit
            List<Intersection> groupeJoueur = GetGroupe(intersection);

            if (CompterLibertes(groupeJoueur) == 0)
            {
                intersection.Value = Pierre.Empty;

                foreach (Intersection pierreCapturee in pierresCapturees)
                    pierreCapturee.Value = adversaire;

                MessageBox.Show(
                    "Coup interdit : suicide.",
                    "Coup invalide",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);

                return;
            }

            if (joueur == Pierre.Black)
                CapturesNoir += captures;
            else
                CapturesBlanc += captures;

            _passesConsecutives = 0;

            ChangerJoueur();
        }

        //Cette méthode vérifie les voisins de la pierre jouée afin de voir si des groupes adverses doivent être capturés.
        private int CapturerGroupesAdverses(Intersection intersection,Pierre adversaire,List<Intersection> pierresCapturees)
        {
            int captures = 0;

            foreach (Intersection voisin in GetVoisins(intersection))
            {
                if (voisin.Value == adversaire)
                {
                    List<Intersection> groupeAdverse = GetGroupe(voisin);

                    int libertes = CompterLibertes(groupeAdverse);

                    if (libertes == 0)
                    {
                        captures += groupeAdverse.Count;

                        foreach (Intersection pierre in groupeAdverse)
                        {
                            pierresCapturees.Add(pierre);
                            pierre.Value = Pierre.Empty;
                        }
                    }
                }
            }

            return captures;
        }

        private void PasserTour(object? parameter)
        {
            if (EstEnPause)
                return;

            _passesConsecutives++;

            if (_passesConsecutives >= 2)
            {
                TerminerPartie();
                return;
            }

            ChangerJoueur();
        }

        private void Pause(object? parameter)
        {
            EstEnPause = !EstEnPause;

            if (EstEnPause)
            {
                _timer.Stop();

                MessageBox.Show(
                    "La partie est en pause.\nAppuyez sur OK pour reprendre.",
                    "Pause",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);

                EstEnPause = false;
                _timer.Start();
            }
        }

        private void Abandonner(object? parameter)
        {
            TerminerPartie(true);
        }

        private void ChangerJoueur()
        {
            JoueurActuel = JoueurActuel == Pierre.Black
                ? Pierre.White
                : Pierre.Black;
        }

        private List<Intersection> GetVoisins(Intersection intersection)
        {
            List<Intersection> voisins = new List<Intersection>();

            int row = intersection.Row;
            int col = intersection.Col;

            AjouterVoisin(voisins, row - 1, col);
            AjouterVoisin(voisins, row + 1, col);
            AjouterVoisin(voisins, row, col - 1);
            AjouterVoisin(voisins, row, col + 1);

            return voisins;
        }

        private void AjouterVoisin(List<Intersection> voisins, int row, int col)
        {
            Intersection? voisin = Plateau.Intersections
                .FirstOrDefault(i => i.Row == row && i.Col == col);

            if (voisin != null)
                voisins.Add(voisin);
        }

        //Cette méthode trouve toutes les pierres connectées de la même couleur.
        private List<Intersection> GetGroupe(Intersection depart)
        {
            List<Intersection> groupe = new List<Intersection>();
            Queue<Intersection> aVerifier = new Queue<Intersection>();

            Pierre couleur = depart.Value;

            aVerifier.Enqueue(depart);

            while (aVerifier.Count > 0)
            {
                Intersection actuelle = aVerifier.Dequeue();

                if (groupe.Contains(actuelle))
                    continue;

                groupe.Add(actuelle);

                foreach (Intersection voisin in GetVoisins(actuelle))
                {
                    if (voisin.Value == couleur && !groupe.Contains(voisin))
                        aVerifier.Enqueue(voisin);
                }
            }

            return groupe;
        }

        //Cette méthode compte les libertés d’un groupe (Une liberté est une intersection vide directement voisine d’une pierre du groupe)
        private int CompterLibertes(List<Intersection> groupe)
        {
            List<Intersection> libertes = new List<Intersection>();

            foreach (Intersection pierre in groupe)
            {
                foreach (Intersection voisin in GetVoisins(pierre))
                {
                    if (voisin.Value == Pierre.Empty && !libertes.Contains(voisin))
                        libertes.Add(voisin);
                }
            }

            return libertes.Count;
        }

        private Pierre GetCouleurAdverse(Pierre couleur)
        {
            return couleur == Pierre.Black ? Pierre.White : Pierre.Black;
        }

        private string GetEtatPlateau()
        {
            return string.Join("",
                Plateau.Intersections
                    .OrderBy(i => i.Row)
                    .ThenBy(i => i.Col)
                    .Select(i => (int)i.Value));
        }
        private void TerminerPartie(bool abandon = false)
        {
            _timer.Stop();
            CalculerTerritoires();

            if (abandon)
            {
                if (JoueurActuel == Pierre.Black)
                    Gagnant = NomJoueurBlanc;
                else
                    Gagnant = NomJoueurNoir;
            }
            else
            {
                if (ScoreNoir > ScoreBlanc)
                    Gagnant = NomJoueurNoir;
                else if (ScoreBlanc > ScoreNoir)
                    Gagnant = NomJoueurBlanc;
                else
                    Gagnant = "Égalité"; //Pas sensé être possible avec un komi sauf si il est de 0
            }

            SauvegardeXmlService.SauvegarderJournal(new JournalPartie
            {
                NomJoueurNoir = NomJoueurNoir,
                NomJoueurBlanc = NomJoueurBlanc,
                NomGagnant = Gagnant,
                TempsPartie = TempsPartie
            });

            ScoreFinalView scoreFinalView = new ScoreFinalView();

            scoreFinalView.DataContext = new ScoreFinalViewModel(
                NomJoueurNoir,
                NomJoueurBlanc,
                Gagnant,
                CapturesNoir,
                CapturesBlanc,
                TerritoireNoir,
                TerritoireBlanc,
                Komi,
                TempsPartie,
                TempsNoir,
                TempsBlanc
            );

            scoreFinalView.Show();

            FermerFenetreJeu();
        }

        //Cette méthode calcule le territoire contrôlé par chaque joueur.
        private void CalculerTerritoires()
        {
            TerritoireNoir = 0;
            TerritoireBlanc = 0;

            List<Intersection> dejaVerifiees = new List<Intersection>();

            foreach (Intersection intersection in Plateau.Intersections)
            {
                if (intersection.Value != Pierre.Empty || dejaVerifiees.Contains(intersection))
                    continue;

                List<Intersection> territoire = new List<Intersection>();
                Queue<Intersection> aVerifier = new Queue<Intersection>();
                List<Pierre> couleursVoisines = new List<Pierre>();

                aVerifier.Enqueue(intersection);

                while (aVerifier.Count > 0)
                {
                    Intersection actuelle = aVerifier.Dequeue();

                    if (dejaVerifiees.Contains(actuelle))
                        continue;

                    dejaVerifiees.Add(actuelle);
                    territoire.Add(actuelle);

                    foreach (Intersection voisin in GetVoisins(actuelle))
                    {
                        if (voisin.Value == Pierre.Empty)
                        {
                            if (!dejaVerifiees.Contains(voisin))
                                aVerifier.Enqueue(voisin);
                        }
                        else
                        {
                            if (!couleursVoisines.Contains(voisin.Value))
                                couleursVoisines.Add(voisin.Value);
                        }
                    }
                }

                if (couleursVoisines.Count == 1)
                {
                    if (couleursVoisines[0] == Pierre.Black)
                        TerritoireNoir += territoire.Count;
                    else if (couleursVoisines[0] == Pierre.White)
                        TerritoireBlanc += territoire.Count;
                }
            }
        }
        private void FermerFenetreJeu()
        {
            foreach (Window window in Application.Current.Windows)
            {
                if (window is JeuView)
                {
                    window.Close();
                    break;
                }
            }
        }
    }
}

