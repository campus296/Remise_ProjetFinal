using Microsoft.VisualBasic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ProjetJeuGo.Models;
using ProjetJeuGo.ViewModels;
using System.Collections.Generic;
using System.Linq;

namespace ProjetJeuGoTests
{
    [TestClass]
    public class ReglesTests
    {
        [TestMethod]
        public void GetCouleurAdverse_Black_RetourneWhite()
        {
            JeuViewModel vm = new JeuViewModel();

            Pierre resultat = vm.GetCouleurAdverse(Pierre.Black);

            Assert.AreEqual(Pierre.White, resultat);
        }

        [TestMethod]
        public void GetCouleurAdverse_White_RetourneBlack()
        {
            JeuViewModel vm = new JeuViewModel();

            Pierre resultat = vm.GetCouleurAdverse(Pierre.White);

            Assert.AreEqual(Pierre.Black, resultat);
        }

        [TestMethod]
        public void GetVoisins_CaseCentre_Retourne4Voisins()
        {
            JeuViewModel vm = new JeuViewModel();

            Intersection centre = vm.Plateau.Intersections
                .First(i => i.Row == 4 && i.Col == 4);

            List<Intersection> voisins = vm.GetVoisins(centre);

            Assert.AreEqual(4, voisins.Count);
        }

        [TestMethod]
        public void GetVoisins_CoinHautGauche_Retourne2Voisins()
        {
            JeuViewModel vm = new JeuViewModel();

            Intersection coin = vm.Plateau.Intersections
                .First(i => i.Row == 0 && i.Col == 0);

            List<Intersection> voisins = vm.GetVoisins(coin);

            Assert.AreEqual(2, voisins.Count);
        }

        [TestMethod]
        public void GetVoisins_BordHaut_Retourne3Voisins()
        {
            JeuViewModel vm = new JeuViewModel();

            Intersection bord = vm.Plateau.Intersections
                .First(i => i.Row == 0 && i.Col == 4);

            List<Intersection> voisins = vm.GetVoisins(bord);

            Assert.AreEqual(3, voisins.Count);
        }

        [TestMethod]
        public void GetGroupe_PierreSeule_Retourne1()
        {
            JeuViewModel vm = new JeuViewModel();

            Intersection pierre = vm.Plateau.Intersections
                .First(i => i.Row == 4 && i.Col == 4);

            pierre.Value = Pierre.Black;

            List<Intersection> groupe = vm.GetGroupe(pierre);

            Assert.AreEqual(1, groupe.Count);
        }

        [TestMethod]
        public void GetGroupe_DeuxPierresConnectees_Retourne2()
        {
            JeuViewModel vm = new JeuViewModel();

            Intersection pierre1 = vm.Plateau.Intersections.First(i => i.Row == 4 && i.Col == 4);
            Intersection pierre2 = vm.Plateau.Intersections.First(i => i.Row == 4 && i.Col == 5);

            pierre1.Value = Pierre.Black;
            pierre2.Value = Pierre.Black;

            List<Intersection> groupe = vm.GetGroupe(pierre1);

            Assert.AreEqual(2, groupe.Count);
        }

        [TestMethod]
        public void GetGroupe_PierresSeparees_Retourne1()
        {
            JeuViewModel vm = new JeuViewModel();

            Intersection pierre1 = vm.Plateau.Intersections.First(i => i.Row == 4 && i.Col == 4);
            Intersection pierre2 = vm.Plateau.Intersections.First(i => i.Row == 6 && i.Col == 6);

            pierre1.Value = Pierre.Black;
            pierre2.Value = Pierre.Black;

            List<Intersection> groupe = vm.GetGroupe(pierre1);

            Assert.AreEqual(1, groupe.Count);
        }

        [TestMethod]
        public void CompterLibertes_PierreSeuleAuCentre_Retourne4()
        {
            JeuViewModel vm = new JeuViewModel();

            Intersection pierre = vm.Plateau.Intersections.First(i => i.Row == 4 && i.Col == 4);
            pierre.Value = Pierre.Black;

            List<Intersection> groupe = vm.GetGroupe(pierre);

            int libertes = vm.CompterLibertes(groupe);

            Assert.AreEqual(4, libertes);
        }

        [TestMethod]
        public void CompterLibertes_PierreDansCoin_Retourne2()
        {
            JeuViewModel vm = new JeuViewModel();

            Intersection pierre = vm.Plateau.Intersections.First(i => i.Row == 0 && i.Col == 0);
            pierre.Value = Pierre.Black;

            List<Intersection> groupe = vm.GetGroupe(pierre);

            int libertes = vm.CompterLibertes(groupe);

            Assert.AreEqual(2, libertes);
        }

        [TestMethod]
        public void CompterLibertes_PierreSurBord_Retourne3()
        {
            JeuViewModel vm = new JeuViewModel();

            Intersection pierre = vm.Plateau.Intersections.First(i => i.Row == 0 && i.Col == 4);
            pierre.Value = Pierre.Black;

            List<Intersection> groupe = vm.GetGroupe(pierre);

            int libertes = vm.CompterLibertes(groupe);

            Assert.AreEqual(3, libertes);
        }

        [TestMethod]
        public void CompterLibertes_PierreEntouree_Retourne0()
        {
            JeuViewModel vm = new JeuViewModel();

            vm.Plateau.Intersections.First(i => i.Row == 4 && i.Col == 4).Value = Pierre.Black;

            vm.Plateau.Intersections.First(i => i.Row == 3 && i.Col == 4).Value = Pierre.White;
            vm.Plateau.Intersections.First(i => i.Row == 5 && i.Col == 4).Value = Pierre.White;
            vm.Plateau.Intersections.First(i => i.Row == 4 && i.Col == 3).Value = Pierre.White;
            vm.Plateau.Intersections.First(i => i.Row == 4 && i.Col == 5).Value = Pierre.White;

            Intersection pierre = vm.Plateau.Intersections.First(i => i.Row == 4 && i.Col == 4);

            List<Intersection> groupe = vm.GetGroupe(pierre);

            int libertes = vm.CompterLibertes(groupe);

            Assert.AreEqual(0, libertes);
        }

        [TestMethod]
        public void GetEtatPlateau_PlateauVide_Retourne81Zeros()
        {
            JeuViewModel vm = new JeuViewModel();

            string etat = vm.GetEtatPlateau();

            Assert.AreEqual(81, etat.Length);
            Assert.IsTrue(etat.All(c => c == '0'));
        }

        [TestMethod]
        public void GetEtatPlateau_AvecPierres_RetourneEtatDifferent()
        {
            JeuViewModel vm = new JeuViewModel();

            string etatAvant = vm.GetEtatPlateau();

            vm.Plateau.Intersections.First(i => i.Row == 0 && i.Col == 0).Value = Pierre.Black;
            vm.Plateau.Intersections.First(i => i.Row == 0 && i.Col == 1).Value = Pierre.White;

            string etatApres = vm.GetEtatPlateau();

            Assert.AreNotEqual(etatAvant, etatApres);
        }

        //Les territoires sont calcul� sur un plateau ferm�s du a un bug (que je n'ai pas r�ussi a corrig�) lors de la pause de la premi�re pierre
        public void CalculerTerritoires_TerritoireNoirSimple_Retourne1()
        {
            JeuViewModel vm = new JeuViewModel();

            foreach (Intersection intersection in vm.Plateau.Intersections)
                intersection.Value = Pierre.White;

            Intersection centre = vm.Plateau.Intersections.First(i => i.Row == 4 && i.Col == 4);
            centre.Value = Pierre.Empty;

            vm.Plateau.Intersections.First(i => i.Row == 4 && i.Col == 3).Value = Pierre.Black;
            vm.Plateau.Intersections.First(i => i.Row == 4 && i.Col == 5).Value = Pierre.Black;
            vm.Plateau.Intersections.First(i => i.Row == 3 && i.Col == 4).Value = Pierre.Black;
            vm.Plateau.Intersections.First(i => i.Row == 5 && i.Col == 4).Value = Pierre.Black;

            vm.CalculerTerritoires();

            Assert.AreEqual(1, vm.TerritoireNoir);
        }

        [TestMethod]
        public void CalculerTerritoires_TerritoireBlancSimple_Retourne1()
        {
            JeuViewModel vm = new JeuViewModel();

            foreach (Intersection intersection in vm.Plateau.Intersections)
                intersection.Value = Pierre.Black;

            Intersection centre = vm.Plateau.Intersections.First(i => i.Row == 4 && i.Col == 4);
            centre.Value = Pierre.Empty;

            vm.Plateau.Intersections.First(i => i.Row == 4 && i.Col == 3).Value = Pierre.White;
            vm.Plateau.Intersections.First(i => i.Row == 4 && i.Col == 5).Value = Pierre.White;
            vm.Plateau.Intersections.First(i => i.Row == 3 && i.Col == 4).Value = Pierre.White;
            vm.Plateau.Intersections.First(i => i.Row == 5 && i.Col == 4).Value = Pierre.White;

            vm.CalculerTerritoires();

            Assert.AreEqual(1, vm.TerritoireBlanc);
        }

        [TestMethod]
        public void ScoreBlanc_AjouteCapturesTerritoireEtKomi()
        {
            JeuViewModel vm = new JeuViewModel("Noir", "Blanc", 9, 6.5);

            vm.CapturesBlanc = 2;
            vm.TerritoireBlanc = 10;

            Assert.AreEqual(18.5, vm.ScoreBlanc);
        }

        [TestMethod]
        public void ScoreNoir_AjouteCapturesEtTerritoire()
        {
            JeuViewModel vm = new JeuViewModel();

            vm.CapturesNoir = 3;
            vm.TerritoireNoir = 12;

            Assert.AreEqual(15, vm.ScoreNoir);
        }

        [TestMethod]
        public void TempsPartie_AdditionneTempsNoirEtBlanc()
        {
            JeuViewModel vm = new JeuViewModel();

            vm.TempsNoir = System.TimeSpan.FromSeconds(30);
            vm.TempsBlanc = System.TimeSpan.FromSeconds(45);

            Assert.AreEqual(System.TimeSpan.FromSeconds(75), vm.TempsPartie);
        }
    }
}