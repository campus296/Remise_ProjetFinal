﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using ProjetJeuGo.Models;

namespace ProjetJeuGo.Services
{
    public static class ConfigurationService
    {
        private static readonly string CheminConfig = "config.xml";

        public static Configuration ChargerConfiguration()
        {
            if (!File.Exists(CheminConfig))
            {
                return new Configuration
                {
                    KomiParDefaut = 6.5,
                    TaillePlateauParDefaut = 9
                };
            }

            XmlSerializer serializer = new XmlSerializer(typeof(Configuration));

            using FileStream fs = new FileStream(CheminConfig, FileMode.Open);
            return (Configuration)serializer.Deserialize(fs)!;
        }
    }
}
