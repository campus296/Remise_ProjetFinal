﻿using ProjetJeuGo.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace ProjetJeuGo.Services
{
    public static class SauvegardeXmlService
    {
        private static readonly string CheminJournal = "journaux-parties.xml";

        public static List<JournalPartie> ChargerJournaux()
        {
            if (!File.Exists(CheminJournal))
                return new List<JournalPartie>();

            XmlSerializer serializer = new XmlSerializer(typeof(List<JournalPartie>));

            using FileStream fs = new FileStream(CheminJournal, FileMode.Open);
            return (List<JournalPartie>)serializer.Deserialize(fs)!;
        }

        public static void SauvegarderJournal(JournalPartie journal)
        {
            List<JournalPartie> journaux = ChargerJournaux();

            journaux.Add(journal);

            XmlSerializer serializer = new XmlSerializer(typeof(List<JournalPartie>));

            using FileStream fs = new FileStream(CheminJournal, FileMode.Create);
            serializer.Serialize(fs, journaux);
        }
    }
}
