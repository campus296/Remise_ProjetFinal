﻿using ProjetJeuGo.Views;
using ProjetJeuGo.Commands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace ProjetJeuGo.ViewModels
{
    public class ScoreFinalViewModel : BaseViewModel
    {
        public TimeSpan TempsPartie { get; set; }

        public TimeSpan TempsNoir { get; set; }
        public TimeSpan TempsBlanc { get; set; }

        public string NomJoueurNoir { get; set; }
        public string NomJoueurBlanc { get; set; }
        public string Gagnant { get; set; }

        public int CapturesNoir { get; set; }
        public int CapturesBlanc { get; set; }

        public double TerritoireNoir { get; set; }
        public double TerritoireBlanc { get; set; }

        public double Komi { get; set; }

        public double ScoreNoir => TerritoireNoir + CapturesNoir;
        public double ScoreBlanc => TerritoireBlanc + CapturesBlanc + Komi;

        public ICommand NouvellePartieCommand { get; }
        public ICommand RejouerCommand { get; }
        public ICommand FermerCommand { get; }


        private readonly string _nomJoueurNoir;
        private readonly string _nomJoueurBlanc;
        private readonly double _komi;

        public ScoreFinalViewModel(
            string nomJoueurNoir,
            string nomJoueurBlanc,
            string gagnant,
            int capturesNoir,
            int capturesBlanc,
            double territoireNoir,
            double territoireBlanc,
            double komi,
            TimeSpan tempsPartie,
            TimeSpan tempsNoir,
            TimeSpan tempsBlanc)
        {
            NomJoueurNoir = nomJoueurNoir;
            NomJoueurBlanc = nomJoueurBlanc;
            Gagnant = gagnant;
            CapturesNoir = capturesNoir;
            CapturesBlanc = capturesBlanc;
            TerritoireNoir = territoireNoir;
            TerritoireBlanc = territoireBlanc;
            Komi = komi;
            TempsPartie = tempsPartie;
            _nomJoueurNoir = nomJoueurNoir;
            _nomJoueurBlanc = nomJoueurBlanc;
            _komi = komi;
            TempsNoir = tempsNoir;
            TempsBlanc = tempsBlanc;

            NouvellePartieCommand = new RelayCommand(NouvellePartie);
            RejouerCommand = new RelayCommand(Rejouer);
            FermerCommand = new RelayCommand(Fermer);
        }

        private void NouvellePartie(object? parameter)
        {
            CreationPartieView view = new CreationPartieView();
            view.Show();

            FermerFenetreScore();
        }

        private void Rejouer(object? parameter)
        {
            JeuView jeuView = new JeuView();

            jeuView.DataContext = new JeuViewModel(
                _nomJoueurNoir,
                _nomJoueurBlanc,
                9,
                _komi
            );

            jeuView.Show();

            FermerFenetreScore();
        }

        private void FermerFenetreScore()
        {
            foreach (Window window in Application.Current.Windows)
            {
                if (window is ScoreFinalView)
                {
                    window.Close();
                    break;
                }
            }
        }

        private void Fermer(object? parameter)
        {
            FermerFenetreScore();
        }
    }
}
