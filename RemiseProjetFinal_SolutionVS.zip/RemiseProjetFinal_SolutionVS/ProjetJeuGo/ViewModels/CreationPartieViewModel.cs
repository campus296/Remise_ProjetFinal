﻿using ProjetJeuGo.Commands;
using ProjetJeuGo.Views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Windows;
using ProjetJeuGo.Services;
using ProjetJeuGo.Models;

namespace ProjetJeuGo.ViewModels
{
    public class CreationPartieViewModel : BaseViewModel
    {
        private string _nomJoueurNoir = "";
        private string _nomJoueurBlanc = "";
        private int _taillePlateau;
        private double _komi;
        private string _messageErreur = "";

        public ICommand DemarrerPartieCommand { get; }

        public string NomJoueurNoir
        {
            get => _nomJoueurNoir;
            set
            {
                _nomJoueurNoir = value;
                OnPropertyChanged(nameof(NomJoueurNoir));
            }
        }

        public string NomJoueurBlanc
        {
            get => _nomJoueurBlanc;
            set
            {
                _nomJoueurBlanc = value;
                OnPropertyChanged(nameof(NomJoueurBlanc));
            }
        }

        public double Komi
        {
            get => _komi;
            set
            {
                _komi = value;
                OnPropertyChanged(nameof(Komi));
            }
        }

        public string MessageErreur
        {
            get => _messageErreur;
            set
            {
                _messageErreur = value;
                OnPropertyChanged(nameof(MessageErreur));
            }
        }

        public int TaillePlateau
        {
            get => _taillePlateau;
            set
            {
                _taillePlateau = value;
                OnPropertyChanged(nameof(TaillePlateau));
            }
        }

        public CreationPartieViewModel()
        {
            Configuration config = ConfigurationService.ChargerConfiguration();

            TaillePlateau = config.TaillePlateauParDefaut;
            Komi = config.KomiParDefaut;

            DemarrerPartieCommand = new RelayCommand(DemarrerPartie);
        }

        private void DemarrerPartie(object? parameter)
        {
            if (string.IsNullOrWhiteSpace(NomJoueurNoir) ||
                string.IsNullOrWhiteSpace(NomJoueurBlanc))
            {
                MessageErreur = "Veuillez entrer le nom des deux joueurs.";
                return;
            }

            JeuView jeuView = new JeuView();

            jeuView.DataContext = new JeuViewModel(
                NomJoueurNoir,
                NomJoueurBlanc,
                TaillePlateau,
                Komi
            );

            jeuView.Show();

            foreach (Window window in Application.Current.Windows)
            {
                if (window is CreationPartieView)
                {
                    window.Close();
                    break;
                }
            }
        }
    }
}
