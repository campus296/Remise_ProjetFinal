﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetJeuGo.Models
{
    public class JournalPartie
    {
        public string NomJoueurNoir { get; set; } = "";
        public string NomJoueurBlanc { get; set; } = "";
        public string NomGagnant { get; set; } = "";

        public int CapturesNoir { get; set; }
        public int CapturesBlanc { get; set; }

        public double TerritoireNoir { get; set; }
        public double TerritoireBlanc { get; set; }

        public double Komi { get; set; }

        public double ScoreNoir { get; set; }
        public double ScoreBlanc { get; set; }

        public TimeSpan TempsNoir { get; set; }
        public TimeSpan TempsBlanc { get; set; }
        public TimeSpan TempsPartie { get; set; }
    }
}
