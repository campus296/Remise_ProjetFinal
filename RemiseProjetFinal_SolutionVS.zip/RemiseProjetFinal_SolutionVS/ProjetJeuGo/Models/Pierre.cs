﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetJeuGo.Models
{
    public enum Pierre
    {
        Empty,
        Black,
        White
    }
}
