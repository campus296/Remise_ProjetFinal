﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetJeuGo.Models
{
    public class Coup
    {
        public int Ligne { get; set; }
        public int Colonne { get; set; }
        public Pierre Joueur { get; set; }
        public bool EstPasser { get; set; }
        public DateTime DateHeure { get; set; } = DateTime.Now;
    }
}
