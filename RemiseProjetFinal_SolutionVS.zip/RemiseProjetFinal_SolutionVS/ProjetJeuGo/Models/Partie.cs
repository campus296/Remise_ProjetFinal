﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetJeuGo.Models
{
    public class Partie
    {
        public string NomJoueurNoir { get; set; } = "";
        public string NomJoueurBlanc { get; set; } = "";

        public Pierre JoueurActuel { get; set; } = Pierre.Black;

        public int TaillePlateau { get; set; } = 9;
        public double Komi { get; set; } = 6.5;

        public int CapturesNoir { get; set; }
        public int CapturesBlanc { get; set; }

        public double TerritoireNoir { get; set; }
        public double TerritoireBlanc { get; set; }

        public double ScoreNoir => TerritoireNoir + CapturesNoir;
        public double ScoreBlanc => TerritoireBlanc + CapturesBlanc + Komi;

        public DateTime HeureDebut { get; set; } = DateTime.Now;

        public TimeSpan TempsJoueurNoir { get; set; }
        public TimeSpan TempsJoueurBlanc { get; set; }
        public TimeSpan TempsPartie
        {
            get => TempsJoueurNoir + TempsJoueurBlanc;
        }

        public bool EstTerminee { get; set; }
        public string Gagnant { get; set; } = "";
    }
}
