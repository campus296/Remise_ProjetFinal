﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace ProjetJeuGo.Models
{
    public class Plateau
    {
        public int Taille { get; set; } = 9;

        public ObservableCollection<Intersection> Intersections { get; set; }

        public Plateau(int taille)
        {
            Taille = taille;
            Intersections = new ObservableCollection<Intersection>();
            Initialiser();
        }

        private void Initialiser()
        {
            for (int i = 0; i < Taille; i++)
            {
                for (int j = 0; j < Taille; j++)
                {
                    Intersections.Add(new Intersection
                    {
                        Row = i,
                        Col = j,
                        Value = Pierre.Empty
                    });
                }
            }
        }       
    }
}
