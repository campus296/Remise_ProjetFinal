﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetJeuGo.Models
{
    public class Configuration
    {
        public double KomiParDefaut { get; set; }
        public int TaillePlateauParDefaut { get; set; }
    }
}
